#ifndef __Timer_H
#define __Timer_H

struct Timer
{
	unsigned long long systicksStart;
	float period;
	unsigned long long* systicks;
};

struct Timer timerNew(unsigned long long* systicks);

float timerElapsed(struct Timer* timer);

#endif
