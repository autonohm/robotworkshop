#ifndef __EULERCONTROLLER_H
#define __EULERCONTROLLER_H

#include "time.h"

struct EulerController
{
	float A[9];
	float b[3];
	float c[3];
	float d;

	float x[3];

	float limitLow;
	float limitHigh;

};

struct EulerController eulerControllerNew(float limitLow, float limitHigh);

void eulerControllerReset(struct EulerController* euler);

void eulerControllerSetPIDParams(struct EulerController* euler, float kp, float ki, float kd);

float eulerControllerNextStep(struct EulerController* euler, float w, float r, float dt);

#endif /* __EULERCONTROLLER_H */
