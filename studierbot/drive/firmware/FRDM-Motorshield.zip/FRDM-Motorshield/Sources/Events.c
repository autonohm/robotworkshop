/* ###################################################################
**     Filename    : Events.c
**     Project     : FRDM-KL25Z
**     Processor   : MKL25Z128VLK4
**     Component   : Events
**     Version     : Driver 01.00
**     Compiler    : GNU C Compiler
**     Date/Time   : 2015-07-31, 22:45, # CodeGen: 0
**     Abstract    :
**         This is user's event module.
**         Put your event handler code here.
**     Settings    :
**     Contents    :
**         No public methods
**
** ###################################################################*/
/*!
** @file Events.c
** @version 01.00
** @brief
**         This is user's event module.
**         Put your event handler code here.
*/         
/*!
**  @addtogroup Events_module Events module documentation
**  @{
*/         
/* MODULE Events */

#include "Cpu.h"
#include "Events.h"

#ifdef __cplusplus
extern "C" {
#endif 

unsigned long long _systemSysticks = 0;
unsigned int _systemTicksEncM1     = 0;
unsigned int _systemTicksEncM2     = 0;

/* User includes (#include below this line is not maintained by Processor Expert) */

void hwTim1_OnTimeOut(void* data)
{
  ++_systemSysticks;
}

void PORTA_IRQHandler(void)
{
  /* Clear interrupt flag.*/
  PORT_HAL_ClearPortIntFlag(PORTA_BASE_PTR);
  /* Write your code here ... */
  _systemTicksEncM1 -= ((GPIO_DRV_ReadPinInput(PinEncM1B) << 1) - 1);
}

void PORTD_IRQHandler(void)
{
  //PORT_HAL_ClearPortIntFlag(PORTD_BASE_PTR);
  /* Write your code here ... */
  // SM: Unfortunately, Encoder 1 is using PORTA and PORTD! -> TODO: rewire
  if(GPIO_DRV_IsPinIntPending(PinEncM1B))
  {
	_systemTicksEncM1 += ((GPIO_DRV_ReadPinInput(PinEncM1A) << 1) - 1);
	GPIO_DRV_ClearPinIntFlag(PinEncM1B);
  }
  else if(GPIO_DRV_IsPinIntPending(PinEncM2A))
  {
	  _systemTicksEncM2 -= ((GPIO_DRV_ReadPinInput(PinEncM2B) << 1) - 1);
	  GPIO_DRV_ClearPinIntFlag(PinEncM2A);
  }
  else if(GPIO_DRV_IsPinIntPending(PinEncM2B))
  {
	  _systemTicksEncM2 += ((GPIO_DRV_ReadPinInput(PinEncM2A) << 1) - 1);
	  GPIO_DRV_ClearPinIntFlag(PinEncM2B);
  }
}

/*! pwm IRQ handler */
void TPM0_IRQHandler(void)
{
  TPM_DRV_IRQHandler(FSL_PWM);
  /* Write your code here ... */
}

/* END Events */

#ifdef __cplusplus
}  /* extern "C" */
#endif 

/*!
** @}
*/
/*
** ###################################################################
**
**     This file was created by Processor Expert 10.5 [05.21]
**     for the Freescale Kinetis series of microcontrollers.
**
** ###################################################################
*/
