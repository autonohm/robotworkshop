#include "Motor.h"
#include "gpioHBrigdeEnable.h"

struct Motor motorNew(uint8_t channel1, uint8_t channel2)
{
	struct Motor motor;
	motor.param = pwm_ChnConfig0;
	motor.channel1 = channel1;
	motor.channel2 = channel2;

	TPM_DRV_PwmStart(FSL_PWM, &(motor.param), motor.channel1);
	TPM_DRV_PwmStart(FSL_PWM, &(motor.param), motor.channel2);
	return motor;
}

void motorStop(struct Motor* motor)
{
	motor->param.uDutyCyclePercent = 0;
	GPIO_DRV_ClearPinOutput(PinHBrigdeEnable);
}

void motorSetVelocity(struct Motor* motor, short w)
{
	struct TpmPwmParam param2 = motor->param;
	if(w>0)
	{
		motor->param.uDutyCyclePercent = 100-w;
		param2.uDutyCyclePercent = 100;
	}
	else
	{
		motor->param.uDutyCyclePercent = 100;
		param2.uDutyCyclePercent = 100+w;
	}
	GPIO_DRV_SetPinOutput(PinHBrigdeEnable);

    TPM_Type *tpmBase = g_tpmBase[FSL_PWM];

    uint32_t freq = TPM_DRV_GetClock(FSL_PWM);
    uint16_t uMod = freq / motor->param.uFrequencyHZ - 1;

    uint16_t uCnv = uMod * motor->param.uDutyCyclePercent / 100;
    if(uCnv >= uMod) uCnv = uMod + 1; // For 100% duty cycle
    TPM_HAL_SetChnCountVal(tpmBase, motor->channel1, uCnv);

    uCnv = uMod * param2.uDutyCyclePercent / 100;
	if(uCnv >= uMod) uCnv = uMod + 1; // For 100% duty cycle
	TPM_HAL_SetChnCountVal(tpmBase, motor->channel2, uCnv);
}
