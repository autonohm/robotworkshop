#include "PIDController.h"

struct PIDController pidControllerNew(float kp, float ki, float kd, float limitLow, float limitHigh)
{
	struct PIDController pid;

	pid.eIntegral = 0.f;
	pid.ePrev     = 0.f;
	pid.kp        = kp;
	pid.ki        = ki;
	pid.kd        = kd;
	pid.limitLow  = limitLow;
	pid.limitHigh = limitHigh;
	pid.init      = 0;

	return pid;
}

void pidControllerReset(struct PIDController* pid)
{
	pid->init = 0;
}

float pidControllerNextStep(struct PIDController* pid, float w, float r, float dt)
{
	if(!pid->init)
	{
		pid->init = 1;
		pid->eIntegral = 0.f;
		return 0.f;
	}

	float e = w - r;

	pid->eIntegral += e * dt;
	float y = pid->kp * e + pid->ki * pid->eIntegral + pid->kd * (e - pid->ePrev) / dt;
	if(y>pid->limitHigh)
	{
		y = pid->limitHigh;
		//pid->eIntegral -= e * dt;
	}
	if(y<pid->limitLow)
	{
		y = pid->limitLow;
		//pid->eIntegral -= e * dt;
	}
	pid->ePrev = e;

	return y;
}
