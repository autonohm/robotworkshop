#ifndef __COMMAND_H_
#define __COMMAND_H_

#define PARAMSCALE 10000.f
#define VALUESCALE 100.f

#define PARAMSCALE_INV 0.0001f
#define VALUESCALE_INV 0.01f

enum CommandType {CMD_OPEN_LOOP=0x00,
				  CMD_CLOSED_LOOP=0x01,
	              CMD_KP=0x02,
				  CMD_KI=0x03,
				  CMD_KD=0x04,
				  CMD_A11=0x05,
				  CMD_A12=0x06,
				  CMD_A13=0x07,
				  CMD_A21=0x08,
				  CMD_A22=0x09,
				  CMD_A23=0x0A,
				  CMD_A31=0x0B,
				  CMD_A32=0x0C,
				  CMD_A33=0x0D,
				  CMD_B1=0x0E,
				  CMD_B2=0x0F,
				  CMD_B3=0x10,
				  CMD_C1=0x11,
				  CMD_C2=0x12,
				  CMD_C3=0x13,
				  CMD_D=0x14,
				  CMD_PENDING=0xF0,
				  CMD_FAILURE=0xFF
				 };

enum StateCommunication { WAIT_FOR_COMMAND=0, RECEIVE_COMMAND=1, ENQUEUE_DATA=2, SEND=3 };

union Data
{
	int cmd[2];
	float param;
};

struct Command
{
	enum CommandType type;
	enum StateCommunication state;
	float input;
	union Data data;
};

struct Command commandNew();

int commandReceive(struct Command* command);

void commandSend (struct Command* command, char txBuf[5u]);

#endif
