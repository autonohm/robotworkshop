#ifndef __PIDController_H
#define __PIDController_H

#include "time.h"

struct PIDController
{
	float kp;
	float ki;
	float kd;

	float eIntegral;
	float ePrev;
	float limitLow;
	float limitHigh;

	int init;
};

struct PIDController pidControllerNew(float kp, float ki, float kd, float limitLow, float limitHigh);

void pidControllerReset(struct PIDController* pid);

float pidControllerNextStep(struct PIDController* pid, float w, float r, float dt);

#endif
