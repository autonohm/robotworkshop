#ifndef __ENCODER_H_
#define __ENCODER_H_

#define TICKS_PER_REVOLUTION 32.f
#define GEAR_RATIO 131.25f

struct LinkedElement
{
	unsigned int id;
	long ticks;
	float dt;
	struct LinkedElement* next;
};

#define ENC_SIZE 50
struct Encoder
{
  struct LinkedElement* oldest;
  struct LinkedElement* newest;
  long ticksSum;
  float dtSum;
};

struct Encoder encoderNew(unsigned int smoothSize);

void encoderAddTicks(struct Encoder* encoder, int ticks, float dt);

float encoderGetRPM(struct Encoder* encoder);

#endif
