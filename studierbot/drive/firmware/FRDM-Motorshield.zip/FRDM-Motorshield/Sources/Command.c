#include "Command.h"
#include <stdio.h>
#include "lpsciCom1.h"

struct Command commandNew()
{
	struct Command command;
	command.state = WAIT_FOR_COMMAND;
	return command;
}

int commandReceive (struct Command* command)
{
	int received = 0;

	static char rxBuf[6u];

	command->type = CMD_PENDING;

	switch(command->state)
	{
		case WAIT_FOR_COMMAND:
		{
			if(kStatus_LPSCI_Success == LPSCI_DRV_ReceiveData(FSL_LPSCICOM1, rxBuf, 6u))
				command->state = RECEIVE_COMMAND;
			break;
		}
		case RECEIVE_COMMAND:
		{
			if (kStatus_LPSCI_Success == LPSCI_DRV_GetReceiveStatus(FSL_LPSCICOM1, NULL))
			{
				char cmd = rxBuf[0];

				int input = ((rxBuf[1] << 24) & 0xFF000000) |
							((rxBuf[2] << 16) & 0x00FF0000) |
							((rxBuf[3] << 8) & 0x0000FF00)  |
							((rxBuf[4] << 0) & 0x000000FF);
				float* finput = (float*)&input;
				command->input = *finput;
				short inputM1 = (rxBuf[1] << 8) & 0xFF00 | (rxBuf[2] << 0) & 0x00FF;
				short inputM2 = (rxBuf[3] << 8) & 0xFF00 | (rxBuf[4] << 0) & 0x00FF;

				command->type = cmd;

				if(rxBuf[5]=='S')
				{
					switch(cmd)
					{
						case CMD_OPEN_LOOP:
						{
							if (inputM1 > 100)       inputM1 =  100;
							else if (inputM1 < -100) inputM1 = -100;
							if (inputM2 > 100)       inputM2 =  100;
							else if (inputM2 < -100) inputM2 = -100;
							command->data.cmd[0] = inputM1;
							command->data.cmd[1] = inputM2;
							break;
						}
						case CMD_CLOSED_LOOP:
						{
							float wM1     = ((float)inputM1) * VALUESCALE_INV;
							float wM2     = ((float)inputM2) * VALUESCALE_INV;
							command->data.cmd[0] = inputM1;
							command->data.cmd[1] = inputM2;
							break;
						}
						default:
						{
							command->type = CMD_FAILURE;
							break;
						}
					}
				}
				else if(rxBuf[5]=='F')
				{
					switch(cmd)
					{
						case CMD_KP:
						{
							command->data.param = command->input;
							break;
						}
						case CMD_KI:
						{
							command->data.param = command->input;
							break;
						}
						case CMD_KD:
						{
							command->data.param = command->input;
							break;
						}
						case CMD_A11:
						case CMD_A12:
						case CMD_A13:
						case CMD_A21:
						case CMD_A22:
						case CMD_A23:
						case CMD_A31:
						case CMD_A32:
						case CMD_A33:
						case CMD_B1:
						case CMD_B2:
						case CMD_B3:
						case CMD_C1:
						case CMD_C2:
						case CMD_C3:
						case CMD_D:
						{
							command->data.param = command->input;
							break;
						}
						default:
						{
							command->type = CMD_FAILURE;
							break;
						}
					} // switch(cmd)
				}
				else
				{
					command->type = CMD_FAILURE;
				}
				received = 1;
				command->state = ENQUEUE_DATA;
			}
			break;
		}
	}
	return received;
}

void commandSend (struct Command* command, char txBuf[5u])
{
	switch(command->state)
	{
		case ENQUEUE_DATA:
		{
			if (kStatus_LPSCI_Success == LPSCI_DRV_SendData(FSL_LPSCICOM1, txBuf, 5u))
				command->state = SEND;
			break;
		}
		case SEND:
		{
			if(kStatus_LPSCI_Success == LPSCI_DRV_GetTransmitStatus(FSL_LPSCICOM1, NULL))
				command->state = WAIT_FOR_COMMAND;
			break;
		}
	}
}
