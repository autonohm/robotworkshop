/* ###################################################################
**     Filename    : main.c
**     Project     : FRDM-KL25Z
**     Processor   : MKL25Z128VLK4
**     Version     : Driver 01.01
**     Compiler    : GNU C Compiler
**     Date/Time   : 2015-07-31, 22:45, # CodeGen: 0
**     Abstract    :
**         Main module.
**         This module contains user's application code.
**     Settings    :
**     Contents    :
**         No public methods
**
** ###################################################################*/
/*!
** @file main.c
** @version 01.01
** @brief
**         Dual channel motor controller with serial interface
*/         
/*!
**  @addtogroup main_module main module documentation
**  @{
*/         
/* MODULE main */


/* Including needed modules to compile this module/procedure */
#include "Cpu.h"
#include "Events.h"
#include "clockMan1.h"
#include "pin_init.h"
#include "osa1.h"
#include "lpsciCom1.h"
#include "hwTim1.h"
#include "gpioEncM1.h"
#include "gpioEncM2.h"
#include "gpioEncEnable.h"
#include "gpioHBrigdeEnable.h"
#include "gpioFault.h"
#include "pwm.h"

#if CPU_INIT_CONFIG
  #include "Init_Config.h"
#endif
/* User includes (#include below this line is not maintained by Processor Expert) */
#include <stdio.h>
#include "Timer.h"
#include "Motor.h"
#include "Encoder.h"
#include "PIDController.h"
#include "EulerController.h"
#include "Command.h"

extern unsigned long long _systemSysticks;
extern unsigned int _systemTicksEncM1;
extern unsigned int _systemTicksEncM2;

unsigned int _ticksEncM1 = 0;
unsigned int _ticksEncM2 = 0;

unsigned long long _systicks;

void floatToOutputBuffer(float val, char buf[5])
{
	int* ival = (int*)&val;
	buf[0] = (char)((*ival & 0xFF000000) >> 24);
	buf[1] = (char)((*ival & 0x00FF0000) >> 16);
	buf[2] = (char)((*ival & 0x0000FF00) >> 8);
	buf[3] = (char)((*ival & 0x000000FF));
	buf[4] = 'F';
}

void intToOutputBuffer(int val, char buf[5])
{
	buf[0] = (char)((val & 0xFF000000) >> 24);
	buf[1] = (char)((val & 0x00FF0000) >> 16);
	buf[2] = (char)((val & 0x0000FF00) >> 8);
	buf[3] = (char)((val & 0x000000FF));
	buf[4] = 'I';
}

void shortToOutputBuffer(short val1, short val2, char buf[5])
{
	buf[0] = (char)((val1 & 0xFF00) >> 8);
	buf[1] = (char)((val1 & 0x00FF));
	buf[2] = (char)((val2 & 0xFF00) >> 8);
	buf[3] = (char)((val2 & 0x00FF));
	buf[4] = 'S';
}

void errorToOutputBuffer(char buf[5])
{
	buf[0] = 0;
	buf[1] = 0;
	buf[2] = 0;
	buf[3] = 0;
	buf[4] = 'E';
}

/*lint -save  -e970 Disable MISRA rule (6.3) checking. */
int main(void)
/*lint -restore Enable MISRA rule (6.3) checking. */
{
  /* Write your local variable definition here */

  /*** Processor Expert internal initialization. DON'T REMOVE THIS CODE!!! ***/
  PE_low_level_init();
  /*** End of Processor Expert internal initialization.                    ***/

  /* Write your code here */
  GPIO_DRV_SetPinOutput(PinEncEnable);
  GPIO_DRV_ClearPinOutput(PinFault);
  GPIO_DRV_ClearPinOutput(PinHBrigdeEnable);

  _systicks   = _systemSysticks;
  struct Timer timerControl = timerNew(&_systicks);

  struct Motor motor1 = motorNew(2, 3);
  struct Motor motor2 = motorNew(0, 1);
  struct Encoder enc1 = encoderNew(50);
  struct Encoder enc2 = encoderNew(50);

  struct Command command;
  command.state = WAIT_FOR_COMMAND;

  float kp        = 1.f;
  float ki        = 0.1f;
  float kd        = 0.f;
  float limitLow  = -100.f;
  float limitHigh = 100.f;
  struct PIDController pid1 = pidControllerNew(kp, ki, kd, limitLow, limitHigh);
  struct PIDController pid2 = pidControllerNew(kp, ki, kd, limitLow, limitHigh);

  struct EulerController euler1 = eulerControllerNew(limitLow, limitHigh);
  struct EulerController euler2 = eulerControllerNew(limitLow, limitHigh);

  float w1 = 0.f;
  float w2 = 0.f;
  float r = 0.f;
  short y1 = 0;
  short y2 = 0;

  float dt     = 0.f;
  float dtCtrl = 0.f;
  float dtCmd  = 0.f;

  float rpmLowPass1 = 0.f;
  float rpmLowPass2 = 0.f;

  int closedLoop = 0;

  for(;;)
  {
	_systicks   = _systemSysticks;
	dt = timerElapsed(&timerControl);

	dtCtrl += dt;
	dtCmd  += dt;

	float r1;
	float r2;

	if(dtCtrl>0.001f)
	{

		unsigned int deltaTicksM1 = _systemTicksEncM1 - _ticksEncM1;
		unsigned int deltaTicksM2 = _systemTicksEncM2 - _ticksEncM2;
		_ticksEncM1 += deltaTicksM1;
		_ticksEncM2 += deltaTicksM2;
		encoderAddTicks(&enc1, deltaTicksM1, dtCtrl);
		encoderAddTicks(&enc2, deltaTicksM2, dtCtrl);
		r1 = encoderGetRPM(&enc1);
		r2 = encoderGetRPM(&enc2);
		rpmLowPass1 = 0.9f * rpmLowPass1 + 0.1f * r1;
		rpmLowPass2 = 0.9f * rpmLowPass2 + 0.1f * r2;

		// y is either set directly (open loop) or via a PID controller (closed loop)
		if(closedLoop)
		{
			y1 = (short)eulerControllerNextStep(&euler1, w1, r1, dtCtrl);
			y2 = (short)eulerControllerNextStep(&euler2, w2, r2, dtCtrl);

			//y1 = (short)pidControllerNextStep(&pid1, w1, r1, dtCtrl);
			//y2 = (short)pidControllerNextStep(&pid2, w2, r2, dtCtrl);
		}

		motorSetVelocity(&motor1, y1);
		motorSetVelocity(&motor2, y2);

		dtCtrl = 0.f;
	}

	char txBuf[5];
	if(command.state <= RECEIVE_COMMAND)
	{
		if(commandReceive(&command))
		{
			if(command.state == ENQUEUE_DATA)
			{
				short srpm0;
				short srpm1;
				switch(command.type)
				{
					case CMD_OPEN_LOOP:
						y1 = command.data.cmd[0];
						y2 = command.data.cmd[1];
						srpm0 = (short)(rpmLowPass1*VALUESCALE+.5f);
						srpm1 = (short)(rpmLowPass2*VALUESCALE+.5f);
						shortToOutputBuffer(srpm0, srpm1, txBuf);
						closedLoop = 0;
						break;
					case CMD_CLOSED_LOOP:
						w1     = ((float)command.data.cmd[0]) * VALUESCALE_INV;
						w2     = ((float)command.data.cmd[1]) * VALUESCALE_INV;
						srpm0 = (short)(rpmLowPass1*VALUESCALE+.5f);
						srpm1 = (short)(rpmLowPass2*VALUESCALE+.5f);
						shortToOutputBuffer(srpm0, srpm1, txBuf);
						closedLoop = 1;
						break;
					case CMD_KP:
						pid1.kp = command.data.param;
						pid2.kp = pid1.kp;
						floatToOutputBuffer(command.data.param, txBuf);
						eulerControllerSetPIDParams(&euler1, pid1.kp, pid1.ki, pid1.kd);
						eulerControllerSetPIDParams(&euler2, pid2.kp, pid2.ki, pid2.kd);
						break;
					case CMD_KI:
						pid1.ki = command.data.param;
						pid2.ki = pid1.ki;
						floatToOutputBuffer(command.data.param, txBuf);
						eulerControllerSetPIDParams(&euler1, pid1.kp, pid1.ki, pid1.kd);
						eulerControllerSetPIDParams(&euler2, pid2.kp, pid2.ki, pid2.kd);
						break;
					case CMD_KD:
						pid1.kd = command.data.param;
						pid2.kd = pid1.kd;
						floatToOutputBuffer(command.data.param, txBuf);
						eulerControllerSetPIDParams(&euler1, pid1.kp, pid1.ki, pid1.kd);
						eulerControllerSetPIDParams(&euler2, pid2.kp, pid2.ki, pid2.kd);
						break;
					case CMD_A11:
					case CMD_A12:
					case CMD_A13:
					case CMD_A21:
					case CMD_A22:
					case CMD_A23:
					case CMD_A31:
					case CMD_A32:
					case CMD_A33:
						euler1.A[command.type-CMD_A11] = command.data.param;
						euler2.A[command.type-CMD_A11] = command.data.param;
						floatToOutputBuffer(command.data.param, txBuf);
						break;
					case CMD_B1:
					case CMD_B2:
					case CMD_B3:
						euler1.b[command.type-CMD_B1] = command.data.param;
						euler2.b[command.type-CMD_B1] = command.data.param;
						floatToOutputBuffer(command.data.param, txBuf);
						break;
					case CMD_C1:
					case CMD_C2:
					case CMD_C3:
						euler1.c[command.type-CMD_C1] = command.data.param;
						euler2.c[command.type-CMD_C1] = command.data.param;
						floatToOutputBuffer(command.data.param, txBuf);
						break;
					case CMD_D:
						euler1.d = command.data.param;
						euler2.d = command.data.param;
						floatToOutputBuffer(command.data.param, txBuf);
						break;
					default:
						y1 = 0.f;
						y2 = 0.f;
						closedLoop = 0;
						errorToOutputBuffer(txBuf);
						break;
				}
			}
			dtCmd = 0.f;
		}
	} // if(command.state <= RECEIVE_COMMAND)
	else
	{
		commandSend(&command, txBuf);
	}

	// Timeout watchdog
	if(dtCmd > 0.3f)
	{
		closedLoop = 0;
		y1 = 0;
		y2 = 0;
		motorStop(&motor1);
		motorStop(&motor2);
		rpmLowPass1 = 0.f;
		rpmLowPass2 = 0.f;
	}

	if(closedLoop==0)
	{
		pidControllerReset(&pid1);
		pidControllerReset(&pid2);
		eulerControllerReset(&euler1);
		eulerControllerReset(&euler2);
	}
  }

  /*** Don't write any code pass this line, or it will be deleted during code generation. ***/
  /*** RTOS startup code. Macro PEX_RTOS_START is defined by the RTOS component. DON'T MODIFY THIS CODE!!! ***/
  #ifdef PEX_RTOS_START
    PEX_RTOS_START();                  /* Startup of the selected RTOS. Macro is defined by the RTOS component. */
  #endif
  /*** End of RTOS startup code.  ***/
  /*** Processor Expert end of main routine. DON'T MODIFY THIS CODE!!! ***/
  for(;;){}
  /*** Processor Expert end of main routine. DON'T WRITE CODE BELOW!!! ***/
} /*** End of main routine. DO NOT MODIFY THIS TEXT!!! ***/

/* END main */
/*!
** @}
*/
/*
** ###################################################################
**
**     This file was created by Processor Expert 10.5 [05.21]
**     for the Freescale Kinetis series of microcontrollers.
**
** ###################################################################
*/
