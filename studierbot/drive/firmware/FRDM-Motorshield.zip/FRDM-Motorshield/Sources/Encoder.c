#include "Encoder.h"
#include <stdlib.h>

struct Encoder encoderNew(unsigned int smoothSize)
{
	struct LinkedElement* first = malloc(sizeof(*first));
	first->id    = 0;
	first->ticks = 0;
	first->dt    = 0.f;

	struct LinkedElement* cur = first;
	for(unsigned int i=0; i<smoothSize-1; i++)
	{
		cur->next        = malloc(sizeof(struct LinkedElement));
		cur->next->id    = i+1;
		cur->next->ticks = 0;
		cur->next->dt    = 0.f;
		cur              = cur->next;
	}
	cur->next = first;

	struct Encoder encoder;
	encoder.oldest = first;
	encoder.newest = cur;
	encoder.ticksSum = 0;
	encoder.dtSum = 0.f;

	return encoder;
}

void encoderAddTicks(struct Encoder* encoder, int ticks, float dt)
{
	encoder->ticksSum      -= encoder->oldest->ticks;
	encoder->dtSum         -= encoder->oldest->dt;
	encoder->newest         = encoder->oldest;
	encoder->oldest         = encoder->oldest->next;
	encoder->newest->ticks  = ticks;
	encoder->newest->dt     = dt;
	encoder->ticksSum      += ticks;
	encoder->dtSum         += dt;
}

float encoderGetRPM(struct Encoder* encoder)
{
	return ((float)(encoder->ticksSum))/TICKS_PER_REVOLUTION/GEAR_RATIO/(encoder->dtSum)*60.f;
}
