#include "EulerController.h"

struct EulerController eulerControllerNew(float limitLow, float limitHigh)
{
	struct EulerController euler;

	float kp = 1.f;
	float ki = 0.f;
	float kd = 0.f;

	eulerControllerSetPIDParams(&euler, kp, ki, kd);

	euler.limitLow = limitLow;
	euler.limitHigh = limitHigh;

	eulerControllerReset(&euler);

	return euler;
}

void eulerControllerReset(struct EulerController* euler)
{
	euler->x[0] = 0.f;
	euler->x[1] = 0.f;
	euler->x[2] = 0.f;
}

void eulerControllerSetPIDParams(struct EulerController* euler, float kp, float ki, float kd)
{
	// parasite time constant
	float Tpar = 0.01f;

	float b2 = kp*Tpar+kd;
	float b1 = kp+ki*Tpar;
	float b0 = ki;
	float a2 = Tpar;
	float a1 = 1;
	float a0 = 0;

	float* A = euler->A;
	float* b = euler->b;
	float* c = euler->c;
	float* d = &(euler->d);

	A[0] = 0;       A[1] = 1;      A[2] = 0;
	A[3] = -a0/a2;  A[4] = -a1/a2; A[5] = 0;
	A[6] = 0;       A[7] = 0;      A[8] = 0;

	b[0]  = 0;
	b[1]  = 1.f/a2;
	b[2]  = 0;

	c[0]  = b0 - b2*a0/a2;
	c[1]  = b1 - b2*a1/a2;
	c[2]  = 0;

	*d     = b2/a2;
}

float eulerControllerNextStep(struct EulerController* euler, float w, float r, float dt)
{
	float e = w - r;

	float* A = euler->A;
	float* b = euler->b;
	float* c = euler->c;
	float d  = euler->d;
	float* x = euler->x;

	float dx = A[0]*x[0] + A[1]*x[1] + A[2]*x[2] + b[0]*e;
	x[0] += dx * dt;

	dx = A[3]*x[0] + A[4]*x[1] + A[5]*x[2] + b[1]*e;
	x[1] += dx * dt;

	dx = A[6]*x[0] + A[7]*x[1] + A[8]*x[2] + b[2]*e;
	x[2] += dx * dt;

	float y = c[0]*x[0] + c[1]*x[1] + c[2]*x[2] + d*e;

	if(y>euler->limitHigh)
		y = euler->limitHigh;
	if(y<euler->limitLow)
		y = euler->limitLow;

	return y;
}
