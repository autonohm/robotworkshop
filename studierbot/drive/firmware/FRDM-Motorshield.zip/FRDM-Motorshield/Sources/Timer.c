#include "Timer.h"
#include "hwTim1.h"

struct Timer timerNew(unsigned long long* systicks)
{
	struct Timer timer;
	timer.systicksStart = *systicks;
	timer.systicks = systicks;
	uint32_t period = HWTIMER_SYS_GetPeriod(&hwTim1_Handle);
	timer.period = (float)period / 1000000.f;
	return timer;
}

float timerElapsed(struct Timer* timer)
{
	unsigned long long systicks = *(timer->systicks);
	float elapsed = (float)(systicks - timer->systicksStart) * timer->period;
	timer->systicksStart = systicks;
	return elapsed;
}
