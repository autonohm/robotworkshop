#ifndef __MOTOR_H_
#define __MOTOR_H_

#include "pwm.h"
#include "Timer.h"

#define TICKS_PER_REVOLUTION 32.f
#define GEAR_RATIO 131.25f

struct Motor
{
	uint8_t channel1;
	uint8_t channel2;
	struct TpmPwmParam param;
};

struct Motor motorNew(uint8_t channel1, uint8_t channel2);

void motorStop(struct Motor* motor);

void motorSetVelocity(struct Motor* motor, short w);

#endif
